package com.example.EmployeeManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import com.example.EmployeeManagementSystem.projection.*;
import org.springframework.boot.AotInitializerNotFoundException;

import com.example.EmployeeManagementSystem.*;
import com.example.EmployeeManagementSystem.entity.*;
import com.example.EmployeeManagementSystem.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @Autowired
    private DepartmentRepository departmentRepository;

    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @PostMapping
    public Department createDepartment(@RequestBody Department department) {
        return departmentRepository.save(department);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Department> updateDepartment(@PathVariable Long id, @RequestBody Department departmentDetails) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new AotInitializerNotFoundException(null, "Department not found"));

        department.setName(departmentDetails.getName());
        

        Department updatedDepartment = departmentRepository.save(department);
        return ResponseEntity.ok(updatedDepartment);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDepartment(@PathVariable Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new AotInitializerNotFoundException(null, "Department not found"));

        departmentRepository.delete(department);
        return ResponseEntity.noContent().build();
    }
}


