package com.example.EmployeeManagementSystem.confiuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@EnableJpaRepositories(
        basePackages = "com.example.employeemanagementsystem.repository.secondary",
        entityManagerFactoryRef = "secondaryEntityManagerFactory",
        transactionManagerRef = "secondaryTransactionManager"
)
public class SecondaryConfiruation {

	@Bean(name = "secondaryDataSource")
    public DataSource secondaryDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/employees_db");
        dataSource.setUsername("root");
        dataSource.setPassword("rootpassword");
        return dataSource;
    }
	
	 @Bean(name = "secondaryEntityManagerFactory")
	    public LocalContainerEntityManagerFactoryBean secondaryEntityManagerFactory(
	            EntityManagerFactoryBuilder builder,
	            @Qualifier("secondaryDataSource") DataSource dataSource) {
	        return builder
	                .dataSource(dataSource)
	                .packages("com.example.employeemanagementsystem.entity.secondary")
	                .persistenceUnit("secondary")
	                .build();
	    }

	    @Bean(name = "secondaryTransactionManager")
	    public PlatformTransactionManager secondaryTransactionManager(
	            @Qualifier("secondaryEntityManagerFactory") LocalContainerEntityManagerFactoryBean secondaryEntityManagerFactory) {
	        return new JpaTransactionManager(secondaryEntityManagerFactory.getObject());
	    }
}
