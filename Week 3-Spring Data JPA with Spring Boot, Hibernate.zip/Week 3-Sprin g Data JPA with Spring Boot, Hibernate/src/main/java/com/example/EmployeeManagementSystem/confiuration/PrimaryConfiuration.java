package com.example.EmployeeManagementSystem.confiuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@EnableJpaRepositories(
        basePackages = "com.example.employeemanagementsystem.repository.primary",
        entityManagerFactoryRef = "primaryEntityManagerFactory",
        transactionManagerRef = "primaryTransactionManager"
)
public class PrimaryConfiuration {

	 @Bean(name = "primaryDataSource")
	    public DataSource primaryDataSource() {
	        DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName("org.h2.Driver");
	        dataSource.setUrl("jdbc:h2:mem:testdb");
	        dataSource.setUsername("sa");
	        dataSource.setPassword("password");
	        return dataSource;
	    }
	 
	 @Bean(name = "primaryEntityManagerFactory")
	    public LocalContainerEntityManagerFactoryBean primaryEntityManagerFactory(
	            EntityManagerFactoryBuilder builder,
	            @Qualifier("primaryDataSource") DataSource dataSource) {
	        return builder
	                .dataSource(dataSource)
	                .packages("com.example.employeemanagementsystem.entity.primary")
	                .persistenceUnit("primary")
	                .build();
	    }

	    @Bean(name = "primaryTransactionManager")
	    public PlatformTransactionManager primaryTransactionManager(
	            @Qualifier("primaryEntityManagerFactory") LocalContainerEntityManagerFactoryBean primaryEntityManagerFactory) {
	        return new JpaTransactionManager(primaryEntityManagerFactory.getObject());
	    }
}
