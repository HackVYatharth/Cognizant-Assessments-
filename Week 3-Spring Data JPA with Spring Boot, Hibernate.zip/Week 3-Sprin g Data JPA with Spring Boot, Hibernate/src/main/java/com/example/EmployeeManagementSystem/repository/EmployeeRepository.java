package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.projection.EmployeeProjection;
import org.hibernate.query.Page;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	
	 //List<Employee> findByDepartmentId(Long departmentId);
	 List<Employee> findByDepartmentName(String DepartmentName);
	 Employee findByEmail(String email);
	 Employee findById(long id);
	 //Employee findByName(String name);
	 
	 //Custom Query Example
	 
	 @Query("SELECT e FROM Employee e WHERE e.name = :name")
	 List<Employee> findByName(@Param("name") String name);
	 
	 // Named Query
	 List<Employee> findByDepartmentId(@Param("departmentId") Long departmentId);
	 
	 //Pagination
	 Page findAll(Pageable pageable);
	 
	  @Query("SELECT e.id AS id, e.name AS name, e.email AS email, d.name AS departmentName " +
	           "FROM Employee e JOIN e.department d")
	    List<EmployeeProjection> findAllEmployeeProjections();
	

}